from setuptools import setup, find_packages

setup(
    name="ft_package",
    version='0.0.1',
    description='A sample test package',
    author="aalhamel",
    author_email="aalhamel@42.fr",
    packages=find_packages(),
    liscence='42_AD'
)
